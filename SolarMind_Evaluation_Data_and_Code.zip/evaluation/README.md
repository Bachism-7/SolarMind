# SolarMind computational evaluation

## What these files are

These are AI-assisted computational evaluation results generated while preparing the SolarMind presentation. They are model-generated data, not measured sun positions, weather, robotic-arm positions, or electrical output. No physical arm was connected or moved during this evaluation. The student team should reproduce and inspect the checks before describing them as team-verified findings.

The original evaluation used the retrieved SolarMind source associated with commit `c201b320a847768b40869488e6dcb8c303851ff9`. The full dependency versions used are in `requirements-evaluation.txt`; pvlib was 0.16.1. The dates in the dataset are simulated scenario dates, not the date the experiment was run.

## Contents

- `original_results/samples.csv`: the original 2,880 baseline rows, including per-row algorithm differences and five-minute direction changes.
- `original_results/summary.json`: the original summary, including the peak-elevation comparison and five simulated-connection checks.
- `run_evaluation.py`: portable version of the analysis script, with only import/output paths adjusted. Place this evaluation folder inside the SolarMind project root. Rerun outputs go to `rerun_results/`, preserving the original results.
- `provenance/original_analysis_script.py`: the exact original analysis script, retained for provenance. Its original workspace-relative output path is not portable; use the runner instead.
- `requirements-evaluation.txt`: package versions from the original evaluation environment (Python 3.12).
- `DATA_DICTIONARY.md`: meanings and units of the CSV columns.

## Sampling

Manually selected coordinates (latitude, longitude in decimal degrees):

| Location | Latitude | Longitude |
|---|---:|---:|
| Vancouver | 49.2827 | -123.1207 |
| Quito | -0.1807 | -78.4678 |
| Greenwich | 51.48 | 0.0 |
| Sydney | -33.8688 | 151.2093 |
| Tromso | 69.6492 | 18.9553 |

Dates: 2024-03-20, 2024-06-21, 2024-09-22, 2024-12-21. Each UTC calendar day was sampled from 00:00 through 23:50 every ten minutes: 144 rows per day, 20 location/date combinations, 2,880 baseline rows. This is a purposeful contrast sample, not a probability sample.

## Completed comparisons

1. **Calculation consistency.** App NREL (`nrel_numpy`) versus pvlib `ephemeris`, with identical coordinates and timestamps and default atmospheric inputs. Differences are angular separations of 3D direction vectors, combining azimuth and apparent elevation. The reported comparison uses the 1,306 rows with baseline apparent elevation >5 degrees. Median 0.0026420842 degrees; maximum 0.0057186066 degrees. The CSV includes differences for all rows, so apply the daylight filter before reproducing those summaries. Both methods share pvlib; neither is an independent physical observation.
2. **Sampling sensitivity.** For each of 20 location/date combinations, rerun at one-minute intervals (28,800 calculated rows in total), then subtract the ten-minute daily maximum apparent elevation from the one-minute maximum. Maximum difference 0.7897185954 degrees. The original analysis did not retain the 28,800 individual fine-resolution rows: it retained their summary. The script recalculates this comparison. This metric concerns sampled daily peak elevation, not general pointing error.
3. **Timing sensitivity.** Shift each baseline timestamp forward by five minutes at the same coordinates. Compare overall direction over the same >5-degree baseline subset. Maximum change 1.2499907952 degrees. Five minutes is an illustrative delay, not a measured communication latency, and this change is expected solar motion rather than calculation error.
4. **Simulated command checks.** Five checks passed: preview does not open hardware, nighttime sending is rejected, another origin is rejected, first unconfirmed publication stops the second, and successful simulated sending preserves servo order 1 then 10. No real serial connection is used. These checks evaluate selected program behaviors, not hardware accuracy or comprehensive safety.
5. **Boundary diagnostic.** Nominal mapping gives pulses 997 and 3 for azimuths 359 and 1 degrees. This exposes a conversion boundary; it does not demonstrate what the real arm would do.

The repository's existing suite was run separately and returned 17 passed, with one dependency deprecation warning. That result is not part of the five-check count in `summary.json`.

## Reproduce on Windows

Use a separate checkout at the cited commit if you need an exact historical reproduction. Do not reset a working project containing uncommitted changes. Put this folder at `<SolarMind>/evaluation`, alongside `app/`, `README.md`, and `pyproject.toml`.

From PowerShell opened at the project root:

```powershell
python -m venv .venv-evaluation
.\.venv-evaluation\Scripts\python.exe -m pip install -r evaluation\requirements-evaluation.txt
.\.venv-evaluation\Scripts\python.exe evaluation\run_evaluation.py
.\.venv-evaluation\Scripts\python.exe -m pytest
```

The runner uses the app code in your checkout. Results may change if you use a newer revision or different calibration/configuration. The original serial mapping used the example's nominal limits and zero tilt offset. Use example settings for comparison; never overwrite your own configuration merely to match a benchmark. The tests substitute a fake connection; they do not commission or move the arm.

## Sharing in the repository

This evaluation folder can be committed after the team reviews and reproduces it. Keep original and team-rerun results distinct and document who ran each evaluation and the source/dependency versions. Do not describe the CSV as real-world physical measurements. Avoid committing virtual environments or a private `serial_login.py` containing credentials.
