"""Read-only model checks. All arm connections are replaced by fakes."""
import csv, json, math
from datetime import datetime, date, UTC
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
import pvlib
from fastapi.testclient import TestClient
from app.solar import calculate_solar_many, sample_local_day
from app.main import create_app
from app import serial_link

OUT=Path('../build/robustness'); OUT.mkdir(exist_ok=True)
locations=[('Vancouver',49.2827,-123.1207),('Quito',-0.1807,-78.4678),('Greenwich',51.48,0.0),('Sydney',-33.8688,151.2093),('Tromso',69.6492,18.9553)]
dates=['2024-03-20','2024-06-21','2024-09-22','2024-12-21']
def separation(a,e,b,f):
    a,e,b,f=map(np.radians,(a,e,b,f))
    u=np.stack([np.cos(e)*np.sin(a),np.cos(e)*np.cos(a),np.sin(e)],axis=-1)
    v=np.stack([np.cos(f)*np.sin(b),np.cos(f)*np.cos(b),np.sin(f)],axis=-1)
    return np.degrees(np.arctan2(np.linalg.norm(np.cross(u,v),axis=-1),np.sum(u*v,axis=-1)))
records=[]; diffs=[]; timediffs=[]; peakdiffs=[]; checks=[]
for name,lat,lon in locations:
  for day in dates:
    sample=sample_local_day(lat,lon,date.fromisoformat(day),'UTC',10)
    timestamps=[datetime.fromisoformat(s['timestamp'].replace('Z','+00:00')) for s in sample['samples']]
    idx=pd.DatetimeIndex(timestamps)
    base=pd.DataFrame(calculate_solar_many(lat,lon,timestamps))
    other=pvlib.solarposition.get_solarposition(idx,lat,lon,method='ephemeris')
    mask=base.apparent_elevation_deg.to_numpy()>5
    delta=separation(base.azimuth_deg,base.apparent_elevation_deg,other.azimuth,other.apparent_elevation)
    shifted=pd.DataFrame(calculate_solar_many(lat,lon,(idx+pd.Timedelta(minutes=5)).to_pydatetime()))
    tdelta=separation(base.azimuth_deg,base.apparent_elevation_deg,shifted.azimuth_deg,shifted.apparent_elevation_deg)
    diffs.extend(delta[mask].tolist());timediffs.extend(tdelta[mask].tolist())
    fine=sample_local_day(lat,lon,date.fromisoformat(day),'UTC',1)
    peakdiffs.append(max(s['apparent_elevation_deg'] for s in fine['samples'])-float(base.apparent_elevation_deg.max()))
    for i,s in enumerate(sample['samples']):
      records.append(dict(location=name,latitude=lat,longitude=lon,date=day,**s,comparison_direction_difference_deg=float(delta[i]),five_minute_direction_change_deg=float(tdelta[i])))

cfg=serial_link.load_config()
client=TestClient(create_app(),base_url='http://127.0.0.1:8765')
body={'latitude':39.742,'longitude':-105.178,'timestamp':'2024-06-21T19:00:00Z'}
with patch('app.serial_link.SerialSession',side_effect=AssertionError('Must not open hardware')):
  preview=client.post('/api/send',json=body)
  checks.append({'name':'Preview opens no hardware','pass':preview.status_code==200 and not preview.json()['sent']})
  night=client.post('/api/send',json={**body,'timestamp':'2024-06-21T07:00:00Z','send':True},headers={'origin':'http://127.0.0.1:8765'})
  checks.append({'name':'Night send rejected before hardware','pass':night.status_code==422})
  forged=client.post('/api/send',json={**body,'send':True},headers={'origin':'http://evil.example'})
  checks.append({'name':'Foreign origin rejected before hardware','pass':forged.status_code==403})
class FakeLink:
  calls=[]
  success=False
  def __init__(self,*a,**kw):pass
  def __enter__(self):return self
  def __exit__(self,*a):pass
  def login(self):pass
  def run(self,line):
    self.calls.append(line)
    return 'publishing #1' if self.success else 'failed'
with patch('app.serial_link.SerialSession',FakeLink):
  reply=client.post('/api/send',json={**body,'send':True},headers={'origin':'http://127.0.0.1:8765'}).json()
  checks.append({'name':'First unconfirmed command stops second','pass':len(FakeLink.calls)==1 and not reply['all_published']})
  FakeLink.calls=[];FakeLink.success=True
  reply=client.post('/api/send',json={**body,'send':True},headers={'origin':'http://127.0.0.1:8765'}).json()
  checks.append({'name':'Successful fake send preserves servo order','pass':[s['servo_id'] for s in reply['steps']]==[1,10] and len(FakeLink.calls)==2})
wrap=[serial_link.servo_pulses(a,45,cfg)[0]['position'] for a in [359,1]]
summary={'sample_count':len(records),'locations':locations,'dates':dates,'interval_minutes':10,'daylight_above_5_count':len(diffs),'finite_angle_count':sum(math.isfinite(r['azimuth_deg']) and math.isfinite(r['apparent_elevation_deg']) for r in records),'algorithm_comparison':{'reference':'pvlib ephemeris, same library, same default atmospheric inputs','median_direction_difference_deg':float(np.median(diffs)),'max_direction_difference_deg':max(diffs)},'five_minute_delay':{'median_direction_change_deg':float(np.median(timediffs)),'max_direction_change_deg':max(timediffs)},'sampling_peak_elevation':{'max_1min_minus_10min_deg':max(peakdiffs),'day_count':20},'fake_hardware_checks':checks,'wrap_example':{'azimuth_degrees':[359,1],'pulse_values':wrap,'pulse_jump':abs(wrap[1]-wrap[0])},'pvlib_version':pvlib.__version__,'physical_measurements':0}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
with (OUT/'samples.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print(json.dumps(summary,indent=2))
