# Baseline CSV data dictionary

| Column | Meaning |
|---|---|
| location | Selected scenario label |
| latitude | Manually specified latitude, decimal degrees north positive |
| longitude | Manually specified longitude, decimal degrees east positive |
| date | Sampled UTC calendar date |
| timestamp | Timezone-aware UTC instant, ISO 8601 |
| epoch_seconds | Unix timestamp in seconds |
| local_timestamp | Timestamp in the chosen sampling zone, which was UTC |
| local_time | Hour and minute in UTC for this evaluation |
| fold | Timezone ambiguity flag, zero for these UTC samples |
| azimuth_deg | Baseline calculated direction, degrees clockwise from north |
| apparent_elevation_deg | Baseline calculated apparent elevation above horizon, degrees |
| comparison_direction_difference_deg | Overall angular separation between NREL and ephemeris predictions, degrees |
| five_minute_direction_change_deg | Overall angular separation between baseline and baseline+5-minute prediction, degrees |

The CSV contains all 2,880 baseline rows. For the algorithm and time-delay summary statistics, filter to `apparent_elevation_deg > 5`, leaving 1,306 rows. Do not use only azimuth differences: compass directions wrap at north, and elevation also matters.

The CSV does not contain physical position error, solar irradiance, panel power, independent reference observations, or the individual one-minute series. Those must not be inferred from its column names.
